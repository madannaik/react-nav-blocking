import { useState } from "react";
import reactLogo from "./assets/react.svg";
import "./App.css";
import { Link, Route, Routes, useNavigate } from "react-router-dom";
import { One } from "./pages/One";
import { Two } from "./pages/Two";
import { Three } from "./pages/Three";

function App() {
  const [count, setCount] = useState(0);
  const navigate = useNavigate();
  return (
    <div className="App">
      <nav>
        <ul>
          <li>
            <Link to={"/"}>ONE</Link>
          </li>
          <li>
            <Link to={"/two"}>TWO</Link>
          </li>
          <li>
            <Link to={"/three"}>THREE</Link>
          </li>
        </ul>
      </nav>
      <Routes>
        <Route path="/" element={<One />} />
        <Route path="/two" element={<Two />} />
        <Route path="/three" element={<Three />} />
      </Routes>
    </div>
  );
}

export default App;
