import { useCallback, useContext, useEffect, useRef, useState } from "react";
import { UNSAFE_NavigationContext as NavigationContext } from "react-router-dom";

function useConfirmExit(confirmExit: () => boolean, when = true) {
  const { navigator } = useContext(NavigationContext);

  useEffect(() => {
    if (!when) {
      return;
    }
    const push = navigator.push;
    const go = navigator.go;

    navigator.go = (...args: Parameters<typeof go>) => {
      const result = confirmExit();
      if (result !== false) {
        go(...args);
      } else {
        window.history.pushState(null, "", window.location.href);
      }
    };
    navigator.push = (...args: Parameters<typeof push>) => {
      const result = confirmExit();
      console.log();
      if (result !== false) {
        push(...args);
      }
    };

    return () => {
      navigator.push = push;
      navigator.go = go;
    };
  }, [navigator, confirmExit, when]);
}

export function usePrompt(message: string, when = true) {
  useEffect(() => {
    if (when) {
      window.onbeforeunload = function (ev) {
        return message;
      };
    }
    return () => {
      window.onbeforeunload = null;
    };
  }, [message, when]);

  useEffect(() => {}, []);
  const confirmExit = useCallback(() => {
    const confirm = window.confirm(message);
    return confirm;
  }, [message]);
  useConfirmExit(confirmExit, when);
}
