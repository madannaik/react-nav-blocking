import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export function useBackPrompt(when = true) {
  const navigate = useNavigate();
  useEffect(() => {
    const onBackButtonEvent = (e: PopStateEvent) => {
      e.preventDefault();
      e.stopPropagation();
      navigate(-1);
    };
    if (when) {
      // Enter an duplicate entry of current location in window history stack for popstate event to work
      window.history.pushState(null, "", window.location.href);
      window.addEventListener("popstate", onBackButtonEvent);
    }
    return () => {
      window.removeEventListener("popstate", onBackButtonEvent);
    };
  }, [when]);
}
