import React from "react";

export const Two = () => {
  return (
    <>
      <div>Two</div>;
    </>
  );
};
