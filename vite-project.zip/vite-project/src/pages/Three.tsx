import React, { useEffect } from "react";

export const Three = () => {
  return <div>Three</div>;
};
