import React, { useState } from "react";
import { useBackPrompt } from "../hooks/useBackPrompt";
import { usePrompt } from "../hooks/usePrompt";

export const One = () => {
  const [isDirty, setIsDirty] = useState(false);

  usePrompt("Do you want to leave the page", isDirty);
  useBackPrompt(isDirty);

  // set isDirty variable to true whenever the from updates
  const onFormUpdate = () => {
    setIsDirty(true);
  };

  return (
    <div>
      <div style={{ color: "white" }}></div>
      <button onClick={() => setIsDirty(!isDirty)}>
        {isDirty ? "true" : "false"}
      </button>
      <form>
        <input type="text" />
      </form>
    </div>
  );
};
